import os
import re
import json
import html
import hashlib
from pathlib import Path

from django.conf import settings
from django.db import connection

from groq import Groq
from pypdf import PdfReader

from core.models import Profile


# ============================================================
# CONFIGURATION
# ============================================================

VECTOR_DIR = Path(settings.BASE_DIR) / "chroma_portfolio"

EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

DEFAULT_K = 5

GROQ_MODEL = getattr(
    settings,
    "GROQ_MODEL",
    "llama-3.3-70b-versatile",
)


# ============================================================
# DATABASE SCHEMA DISCOVERY
# ============================================================

def discover_schema():
    """
    Dynamically discover Django database tables and columns.

    No hardcoded model/table names are used.
    """

    schema = {}

    table_names = connection.introspection.table_names()

    with connection.cursor() as cursor:

        for table in table_names:

            try:
                description = connection.introspection.get_table_description(
                    cursor,
                    table,
                )

                columns = []

                for column in description:
                    columns.append(column.name)

                schema[table] = columns

            except Exception:
                continue

    return schema


# ============================================================
# PUBLIC TABLE DETECTION
# ============================================================

def is_public_table(table_name, columns):
    """
    Determine whether a table can safely participate
    in the portfolio assistant.

    Tables containing obvious private/auth data are excluded.
    """

    excluded_tables = {
        "auth_user",
        "auth_group",
        "auth_permission",
        "django_admin_log",
        "django_session",
        "django_migrations",
        "django_content_type",
    }

    if table_name.lower() in excluded_tables:
        return False

    sensitive_words = {
        "password",
        "token",
        "secret",
        "session",
        "permission",
        "credential",
    }

    for column in columns:

        column_lower = column.lower()

        if any(word in column_lower for word in sensitive_words):
            return False

    return True


# ============================================================
# SERIALIZATION
# ============================================================

def serialize_value(value):

    if value is None:
        return "NULL"

    if isinstance(value, bytes):
        return "[binary data]"

    return str(value)


def serialize_row(table, columns, row):

    parts = []

    for column, value in zip(columns, row):

        parts.append(
            f"{column}: {serialize_value(value)}"
        )

    return (
        f"Table: {table}\n"
        + "\n".join(parts)
    )


# ============================================================
# DATABASE FINGERPRINT
# ============================================================

def database_fingerprint(schema):
    """
    Generate a fingerprint based on the current database content.

    Used to determine whether the vector database needs rebuilding.
    """

    hasher = hashlib.sha256()

    with connection.cursor() as cursor:

        for table, columns in sorted(schema.items()):

            if not is_public_table(table, columns):
                continue

            try:

                cursor.execute(
                    f'SELECT * FROM "{table}"'
                )

                rows = cursor.fetchall()

                hasher.update(
                    table.encode("utf-8")
                )

                for row in rows:

                    hasher.update(
                        repr(row).encode("utf-8")
                    )

            except Exception:
                continue

    profile = Profile.objects.filter(
        is_active=True,
        resume__isnull=False,
    ).exclude(resume="").first()

    if profile and profile.resume:
        try:
            resume_path = Path(profile.resume.path)
            hasher.update(b"resume")
            hasher.update(resume_path.read_bytes())
        except (FileNotFoundError, OSError):
            pass

    return hasher.hexdigest()


def build_resume_document():
    profile = Profile.objects.filter(
        is_active=True,
        resume__isnull=False,
    ).exclude(resume="").first()

    if not profile or not profile.resume:
        return None

    try:
        reader = PdfReader(profile.resume.path)
        resume_text = "\n".join(
            page.extract_text() or ""
            for page in reader.pages
        ).strip()
    except (FileNotFoundError, OSError, ValueError):
        return None

    if not resume_text:
        return None

    return {
        "text": "Resume PDF:\n" + resume_text,
        "metadata": {
            "source": "resume",
        },
    }


# ============================================================
# BUILD DOCUMENTS
# ============================================================

def build_documents(schema):

    documents = []

    with connection.cursor() as cursor:

        for table, columns in schema.items():

            if not is_public_table(table, columns):
                continue

            try:

                cursor.execute(
                    f'SELECT * FROM "{table}"'
                )

                rows = cursor.fetchall()

                for row in rows:

                    text = serialize_row(
                        table,
                        columns,
                        row,
                    )

                    documents.append(
                        {
                            "text": text,
                            "metadata": {
                                "table": table,
                            },
                        }
                    )

            except Exception:
                continue

    resume_document = build_resume_document()

    if resume_document:
        documents.append(resume_document)

    return documents


# ============================================================
# VECTOR STORE
# ============================================================

def get_vector_store(schema):

    try:
        from langchain_huggingface import HuggingFaceEmbeddings
        from langchain_chroma import Chroma
    except ImportError:
        return None

    VECTOR_DIR.mkdir(
        parents=True,
        exist_ok=True,
    )

    fingerprint = database_fingerprint(schema)

    fingerprint_file = (
        VECTOR_DIR / "database_fingerprint.txt"
    )

    old_fingerprint = None

    if fingerprint_file.exists():

        old_fingerprint = (
            fingerprint_file
            .read_text()
            .strip()
        )

    embeddings = HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODEL
    )

    # --------------------------------------------------------
    # Existing vector store
    # --------------------------------------------------------

    if old_fingerprint == fingerprint:

        return Chroma(
            collection_name="portfolio",
            embedding_function=embeddings,
            persist_directory=str(VECTOR_DIR),
        )

    # --------------------------------------------------------
    # Database changed -> rebuild
    # --------------------------------------------------------

    documents = build_documents(schema)

    texts = [
        item["text"]
        for item in documents
    ]

    metadatas = [
        item["metadata"]
        for item in documents
    ]

    if not texts:

        return Chroma(
            collection_name="portfolio",
            embedding_function=embeddings,
            persist_directory=str(VECTOR_DIR),
        )

    db = Chroma(
        collection_name="portfolio",
        embedding_function=embeddings,
        persist_directory=str(VECTOR_DIR),
    )

    # Delete old collection content
    try:
        db.delete_collection()
    except Exception:
        pass

    db = Chroma.from_texts(
        texts=texts,
        embedding=embeddings,
        metadatas=metadatas,
        collection_name="portfolio",
        persist_directory=str(VECTOR_DIR),
    )

    fingerprint_file.write_text(
        fingerprint,
        encoding="utf-8",
    )

    return db


# ============================================================
# SQL CLEANING
# ============================================================

def clean_sql(sql):

    sql = sql.strip()

    # Remove markdown code blocks
    sql = re.sub(
        r"```sql\s*",
        "",
        sql,
        flags=re.IGNORECASE,
    )

    sql = re.sub(
        r"```\s*$",
        "",
        sql,
        flags=re.IGNORECASE,
    )

    sql = sql.strip()

    return sql


# ============================================================
# SQL SAFETY
# ============================================================

def validate_sql(sql, schema):

    sql = clean_sql(sql)

    if not sql:
        raise ValueError("Empty SQL query.")

    # Must start with SELECT
    if not re.match(
        r"^\s*SELECT\b",
        sql,
        flags=re.IGNORECASE,
    ):
        raise ValueError(
            "Only SELECT queries are allowed."
        )

    # No multiple statements
    if ";" in sql.rstrip(";"):
        raise ValueError(
            "Multiple SQL statements are not allowed."
        )

    forbidden = [
        "INSERT",
        "UPDATE",
        "DELETE",
        "DROP",
        "ALTER",
        "CREATE",
        "REPLACE",
        "TRUNCATE",
        "ATTACH",
        "DETACH",
        "PRAGMA",
        "VACUUM",
        "REINDEX",
    ]

    upper_sql = sql.upper()

    for keyword in forbidden:

        if re.search(
            rf"\b{keyword}\b",
            upper_sql,
        ):
            raise ValueError(
                f"Unsafe SQL keyword detected: {keyword}"
            )

    # Limit query size
    if len(sql) > 5000:
        raise ValueError(
            "SQL query is too long."
        )

    return sql


# ============================================================
# SQL GENERATION
# ============================================================

def generate_sql(
    client,
    schema,
    user_query,
):

    safe_schema = {
        table: columns
        for table, columns in schema.items()
        if is_public_table(table, columns)
    }

    schema_text = json.dumps(
        safe_schema,
        indent=2,
    )

    prompt = f"""
You are a SQL query generator for a Django portfolio database.

DATABASE SCHEMA:
{schema_text}

USER QUESTION:
{user_query}

RULES:

1. Generate ONLY one SQL SELECT query.
2. Use ONLY tables and columns present in the schema.
3. Never use INSERT.
4. Never use UPDATE.
5. Never use DELETE.
6. Never use DROP.
7. Never use ALTER.
8. Never use CREATE.
9. Never use PRAGMA.
10. Never access excluded/private tables.
11. Do not modify the database.
12. Use SQLite-compatible SQL.
13. Return ONLY SQL.
"""

    completion = client.chat.completions.create(
        model=GROQ_MODEL,
        temperature=0,
        max_tokens=500,
        reasoning_effort="low",
        messages=[
            {
                "role": "system",
                "content": (
                    "You generate safe read-only "
                    "SQLite SELECT queries."
                ),
            },
            {
                "role": "user",
                "content": prompt,
            },
        ],
    )

    sql = completion.choices[0].message.content or ""

    return validate_sql(
        sql,
        safe_schema,
    )


# ============================================================
# SQL EXECUTION
# ============================================================

def execute_sql(sql):

    sql = clean_sql(sql)

    with connection.cursor() as cursor:

        cursor.execute(sql)

        rows = cursor.fetchall()

        columns = [
            column[0]
            for column in cursor.description
        ] if cursor.description else []

    return {
        "columns": columns,
        "rows": rows,
    }


# ============================================================
# FORMAT SQL RESULTS
# ============================================================

def format_sql_results(results):

    columns = results["columns"]
    rows = results["rows"]

    if not rows:
        return "No structured database results found."

    formatted = []

    for row in rows:

        parts = []

        for column, value in zip(
            columns,
            row,
        ):

            parts.append(
                f"{column}: {serialize_value(value)}"
            )

        formatted.append(
            " | ".join(parts)
        )

    return "\n".join(formatted)


# ============================================================
# SEMANTIC SEARCH
# ============================================================

def semantic_search(
    vector_store,
    user_query,
):

    if vector_store is None:
        return ""

    try:

        documents = vector_store.similarity_search(
            user_query,
            k=DEFAULT_K,
        )

    except Exception:
        return ""

    if not documents:
        return ""

    return "\n\n".join(
        doc.page_content
        for doc in documents
    )


# ============================================================
# FINAL ANSWER
# ============================================================

def generate_final_answer(
    client,
    user_query,
    sql_context,
    semantic_context,
):

    prompt = f"""
You are JivaAi, a read-only AI assistant for Jivan's portfolio.

Answer the user's question ONLY using the supplied database
information.

USER QUESTION:
{user_query}

STRUCTURED DATABASE RESULTS:
{sql_context}

SEMANTIC DATABASE CONTEXT:
{semantic_context}

RULES:

1. Never invent information.
2. Never use outside knowledge.
3. Never use the internet.
4. Never assume information that is not present.
5. If the information is unavailable, say:

"I can only answer from Jivan's portfolio database and resume.
That information is not available there."

6. Keep the answer concise and professional.
7. Do not mention SQL.
8. Do not mention RAG.
9. Do not mention embeddings.
10. Do not mention the vector database.
11. Do not expose internal implementation details.
12. Never claim to modify, create, delete, or submit anything.
13. Write naturally for a portfolio visitor, beginning with a direct answer.
14. When listing skills, projects, services, or experience, group related items
    under short Markdown headings and use concise bullet points.
15. Use Markdown only: ## headings, - bullets, and **bold labels**.
16. Do not repeat database field names or produce a raw data dump.
17. For a greeting such as "hello" or "hi", reply briefly and warmly. Introduce
    yourself as JivaAi and ask what the visitor would like to learn about Jivan.
18. Never return HTML tags such as <p>, <strong>, or <br>.
19. Return only the final answer, with no preamble about how you found it.
"""

    completion = client.chat.completions.create(
        model=GROQ_MODEL,
        temperature=0,
        max_tokens=900,
        reasoning_effort="low",
        messages=[
            {
                "role": "system",
                "content": prompt,
            },
            {
                "role": "user",
                "content": user_query,
            },
        ],
    )

    answer = (
        completion.choices[0]
        .message
        .content
        or ""
    )

    # Normalize occasional HTML output from the model before the UI renders it.
    answer = html.unescape(answer)
    answer = re.sub(
        r"<think>.*?</think>",
        "",
        answer,
        flags=re.DOTALL | re.IGNORECASE,
    ).strip()
    answer = re.sub(r"</?(?:p|strong|em|br|h[1-6]|ul|ol|li)[^>]*>", "", answer, flags=re.IGNORECASE)

    if not answer:

        answer = (
            "I can only answer from Jivan's portfolio "
            "database and resume."
        )

    return answer


# ============================================================
# MAIN RAG PIPELINE
# ============================================================

def handle_query(user_query):

    if not user_query:
        raise ValueError(
            "Question cannot be empty."
        )

    if not settings.GROQ_API_KEY:
        raise ValueError(
            "GROQ_API_KEY is not configured."
        )

    if re.fullmatch(
        r"(?:hi|hello|hey|good morning|good afternoon|good evening)[!. ]*",
        user_query.strip(),
        flags=re.IGNORECASE,
    ):
        return {
            "answer": (
                "Hello! I'm JivaAi, Jivan's portfolio assistant. "
                "I can help you explore his skills, projects, experience, "
                "and automation work. What would you like to know?"
            ),
            "sql": "",
            "semantic_context": "",
        }

    # --------------------------------------------------------
    # 1. Discover database dynamically
    # --------------------------------------------------------

    schema = discover_schema()

    # --------------------------------------------------------
    # 2. Create/load vector store
    # --------------------------------------------------------

    vector_store = get_vector_store(
        schema
    )

    # --------------------------------------------------------
    # 3. Groq client
    # --------------------------------------------------------

    client = Groq(
        api_key=settings.GROQ_API_KEY
    )

    # --------------------------------------------------------
    # 4. Semantic retrieval
    # --------------------------------------------------------

    semantic_context = semantic_search(
        vector_store,
        user_query,
    )

    resume_document = build_resume_document()

    if resume_document:
        semantic_context = "\n\n".join(
            part
            for part in (
                semantic_context,
                resume_document["text"],
            )
            if part
        )

    # --------------------------------------------------------
    # 5. Generate SQL
    # --------------------------------------------------------

    try:

        sql_query = generate_sql(
            client,
            schema,
            user_query,
        )

        # ----------------------------------------------------
        # 6. Execute SQL
        # ----------------------------------------------------

        sql_results = execute_sql(
            sql_query
        )

        sql_context = format_sql_results(
            sql_results
        )

    except Exception as exc:

        # If SQL generation/execution fails,
        # semantic retrieval can still answer.
        sql_query = ""
        sql_context = (
            "Structured database query was unavailable."
        )

    # --------------------------------------------------------
    # 7. Generate final response
    # --------------------------------------------------------

    answer = generate_final_answer(
        client=client,
        user_query=user_query,
        sql_context=sql_context,
        semantic_context=semantic_context,
    )

    return {
        "answer": answer,
        "sql": sql_query,
        "semantic_context": semantic_context,
    }