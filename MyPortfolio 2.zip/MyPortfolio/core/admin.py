from django.contrib import admin

from .models import (
    Profile,
    Skill,
    Technology,
    Education,
    Experience,
    Service,
    Project,
    Testimonial,
    ContactMessage,
    SiteStatistic,
)


# ============================================================
# PROFILE ADMIN
# ============================================================

@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):

    list_display = (
        "name",
        "role",
        "email",
        "phone_primary",
        "is_active",
        "updated_at",
    )

    list_filter = (
        "is_active",
    )

    search_fields = (
        "name",
        "full_name",
        "email",
        "role",
    )


# ============================================================
# SKILL ADMIN
# ============================================================

@admin.register(Skill)
class SkillAdmin(admin.ModelAdmin):

    list_display = (
        "name",
        "category",
        "percentage",
        "is_primary",
        "display_order",
        "is_active",
    )

    list_filter = (
        "category",
        "is_primary",
        "is_active",
    )

    search_fields = (
        "name",
        "description",
    )

    list_editable = (
        "percentage",
        "display_order",
        "is_active",
    )


# ============================================================
# TECHNOLOGY ADMIN
# ============================================================

@admin.register(Technology)
class TechnologyAdmin(admin.ModelAdmin):

    list_display = (
        "name",
        "display_order",
        "is_active",
    )

    list_filter = (
        "is_active",
    )

    search_fields = (
        "name",
    )

    list_editable = (
        "display_order",
        "is_active",
    )


# ============================================================
# EDUCATION ADMIN
# ============================================================

@admin.register(Education)
class EducationAdmin(admin.ModelAdmin):

    list_display = (
        "degree",
        "field_of_study",
        "institution",
        "start_year",
        "end_year",
        "display_order",
        "is_active",
    )

    list_filter = (
        "is_active",
    )

    search_fields = (
        "degree",
        "field_of_study",
        "institution",
    )

    list_editable = (
        "display_order",
        "is_active",
    )


# ============================================================
# EXPERIENCE ADMIN
# ============================================================

@admin.register(Experience)
class ExperienceAdmin(admin.ModelAdmin):

    list_display = (
        "title",
        "company",
        "start_date",
        "end_date",
        "display_order",
        "is_active",
    )

    list_filter = (
        "is_active",
    )

    search_fields = (
        "title",
        "company",
        "description",
    )

    list_editable = (
        "display_order",
        "is_active",
    )


# ============================================================
# SERVICE ADMIN
# ============================================================

@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):

    list_display = (
        "title",
        "display_order",
        "is_active",
    )

    list_filter = (
        "is_active",
    )

    search_fields = (
        "title",
        "description",
    )

    list_editable = (
        "display_order",
        "is_active",
    )


# ============================================================
# PROJECT ADMIN
# ============================================================

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):

    list_display = (
        "title",
        "category",
        "featured",
        "display_order",
        "is_active",
        "created_at",
    )

    list_filter = (
        "category",
        "featured",
        "is_active",
    )

    search_fields = (
        "title",
        "description",
        "technologies",
    )

    list_editable = (
        "featured",
        "display_order",
        "is_active",
    )

    prepopulated_fields = {}


# ============================================================
# TESTIMONIAL ADMIN
# ============================================================

@admin.register(Testimonial)
class TestimonialAdmin(admin.ModelAdmin):

    list_display = (
        "name",
        "designation",
        "company",
        "display_order",
        "is_active",
    )

    list_filter = (
        "is_active",
    )

    search_fields = (
        "name",
        "designation",
        "company",
        "message",
    )

    list_editable = (
        "display_order",
        "is_active",
    )


# ============================================================
# CONTACT MESSAGE ADMIN
# ============================================================

@admin.register(ContactMessage)
class ContactMessageAdmin(admin.ModelAdmin):

    list_display = (
        "name",
        "email",
        "subject",
        "is_read",
        "created_at",
    )

    list_filter = (
        "is_read",
        "created_at",
    )

    search_fields = (
        "name",
        "email",
        "subject",
        "message",
    )

    list_editable = (
        "is_read",
    )

    readonly_fields = (
        "created_at",
    )


# ============================================================
# SITE STATISTICS ADMIN
# ============================================================

@admin.register(SiteStatistic)
class SiteStatisticAdmin(admin.ModelAdmin):

    list_display = (
        "title",
        "stat_type",
        "value",
        "display_order",
        "is_active",
    )

    list_filter = (
        "stat_type",
        "is_active",
    )

    list_editable = (
        "value",
        "display_order",
        "is_active",
    )

    search_fields = (
        "title",
    )


# ============================================================
# ADMIN SITE CONFIG
# ============================================================

admin.site.site_header = "Jivan Ghule Portfolio"
admin.site.site_title = "Jivan Portfolio Admin"
admin.site.index_title = "Portfolio Management Dashboard"