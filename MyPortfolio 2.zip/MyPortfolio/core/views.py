import re

from django.conf import settings
from django.http import JsonResponse
from django.contrib import messages
from django.shortcuts import render, redirect
from django.utils import timezone
from .services.rag_pipeline import handle_query

from groq import Groq
from pypdf import PdfReader

from .models import (
    Profile,
    Skill,
    Technology,
    Education,
    Experience,
    Service,
    Project,
    Testimonial,
    ContactMessage,
    SiteStatistic,
)


CHAT_LIMIT = 50
CHAT_COUNT_SESSION_KEY = "jiva_ai_daily_count"
CHAT_DATE_SESSION_KEY = "jiva_ai_daily_date"


# def _database_context():
#     """Return only public portfolio data that can be used by the model."""
#     profile = Profile.objects.filter(is_active=True).first()
#     sections = []

#     if profile:
#         sections.append(
#             "PROFILE\n"
#             f"Name: {profile.name}\nFull name: {profile.full_name}\n"
#             f"Role: {profile.role}\nBio: {profile.short_bio}\n"
#             f"About: {profile.about_title}; {profile.about_description_1}; "
#             f"{profile.about_description_2}\nExperience label: {profile.experience}\n"
#             f"Address: {profile.address}\nAvailability: {profile.availability_text}\n"
#             f"Email: {profile.email}\nPhone: {profile.phone_primary}, {profile.phone_secondary}\n"
#             f"Links: GitHub {profile.github}; LinkedIn {profile.linkedin}; "
#             f"Twitter {profile.twitter}; Instagram {profile.instagram}"
#         )

#     sections.append("SKILLS\n" + "\n".join(
#         f"{item.name} ({item.category}): {item.description}"
#         for item in Skill.objects.filter(is_active=True)
#     ))
#     sections.append("TECHNOLOGIES\n" + "\n".join(
#         item.name for item in Technology.objects.filter(is_active=True)
#     ))
#     sections.append("EDUCATION\n" + "\n".join(
#         f"{item.degree}, {item.field_of_study}, {item.institution}, "
#         f"{item.start_year}-{item.end_year}, {item.grade}: {item.description}"
#         for item in Education.objects.filter(is_active=True)
#     ))
#     sections.append("EXPERIENCE\n" + "\n".join(
#         f"{item.title} at {item.company}, {item.start_date}-{item.end_date}: "
#         f"{item.description}; Technologies: {item.technologies}"
#         for item in Experience.objects.filter(is_active=True)
#     ))
#     sections.append("SERVICES\n" + "\n".join(
#         f"{item.title}: {item.description}"
#         for item in Service.objects.filter(is_active=True)
#     ))
#     sections.append("PROJECTS\n" + "\n".join(
#         f"{item.title} ({item.category_label or item.category}): {item.description}; "
#         f"Technologies: {item.technologies}; Live URL: {item.live_url}; "
#         f"GitHub URL: {item.github_url}"
#         for item in Project.objects.filter(is_active=True)
#     ))
#     sections.append("TESTIMONIALS\n" + "\n".join(
#         f"{item.name}, {item.designation}, {item.company}: {item.message}"
#         for item in Testimonial.objects.filter(is_active=True)
#     ))
#     sections.append("SITE STATISTICS\n" + "\n".join(
#         f"{item.title}: {item.value}"
#         for item in SiteStatistic.objects.filter(is_active=True)
#     ))

#     if profile and profile.resume:
#         try:
#             reader = PdfReader(profile.resume.path)
#             resume_text = "\n".join(page.extract_text() or "" for page in reader.pages)
#             sections.append("RESUME PDF\n" + resume_text)
#         except Exception:
#             sections.append("RESUME PDF\nThe resume file is stored but its text could not be extracted.")

#     return "\n\n".join(sections)


# def chat_api(request):
#     if request.method != "GET":
#         return JsonResponse({"error": "This read-only endpoint accepts GET requests only."}, status=405)

#     question = request.GET.get("message", "").strip()
#     if not question:
#         return JsonResponse({"error": "Enter a question."}, status=400)

#     today = timezone.localdate().isoformat()
#     if request.session.get(CHAT_DATE_SESSION_KEY) != today:
#         request.session[CHAT_DATE_SESSION_KEY] = today
#         request.session[CHAT_COUNT_SESSION_KEY] = 0

#     count = request.session.get(CHAT_COUNT_SESSION_KEY, 0)
#     if count >= CHAT_LIMIT:
#         return JsonResponse({"error": "JivaAi has reached today's 50-message limit. Please come back tomorrow."}, status=429)

#     if not settings.GROQ_API_KEY:
#         return JsonResponse({"error": "JivaAi is not configured yet."}, status=503)

#     try:
#         client = Groq(api_key=settings.GROQ_API_KEY)
#         completion = client.chat.completions.create(
#             model=settings.GROQ_MODEL,
#             temperature=0,
#             max_tokens=900,
#             reasoning_effort="none",
#             messages=[
#                 {
#                     "role": "system",
#                     "content": (
#                         "You are JivaAi, a read-only portfolio assistant. Answer only using "
#                         "the supplied PORTFOLIO DATABASE CONTEXT. Do not use general knowledge, "
#                         "the internet, Google, or assumptions. If the answer is absent, say: "
#                         "I can only answer from Jivan's portfolio database and resume. That "
#                         "information is not available there. Do not add suggestions or details. "
#                         "Never claim to create, change, delete, or submit anything. Return only "
#                         "the final answer as clean plain text. Never include analysis, reasoning, "
#                         "word counting, XML, or <think> tags. Follow requested word counts.\n\n"
#                         "PORTFOLIO DATABASE CONTEXT:\n" + _database_context()
#                     ),
#                 },
#                 {"role": "user", "content": question},
#             ],
#         )
#         raw_answer = completion.choices[0].message.content or ""
#         answer = re.sub(
#             r"<think>.*?</think>",
#             "",
#             raw_answer,
#             flags=re.DOTALL | re.IGNORECASE,
#         ).strip()
#         if "<think>" in raw_answer.lower() and "</think>" not in raw_answer.lower():
#             answer = raw_answer.split("<think>", 1)[0].strip()
#         if not answer:
#             answer = "I can only answer from Jivan's portfolio database and resume."
#     except Exception:
#         return JsonResponse({"error": "JivaAi could not answer right now. Please try again."}, status=502)

#     request.session[CHAT_COUNT_SESSION_KEY] = count + 1
#     request.session.modified = True
#     return JsonResponse({"answer": answer, "remaining": CHAT_LIMIT - count - 1})




def chat_api(request):

    if request.method != "GET":

        return JsonResponse(
            {
                "error": (
                    "This read-only endpoint accepts "
                    "GET requests only."
                )
            },
            status=405,
        )

    question = request.GET.get(
        "message",
        "",
    ).strip()

    if not question:

        return JsonResponse(
            {
                "error": "Enter a question."
            },
            status=400,
        )

    # ========================================================
    # DAILY LIMIT
    # ========================================================

    today = timezone.localdate().isoformat()

    if request.session.get(
        CHAT_DATE_SESSION_KEY
    ) != today:

        request.session[
            CHAT_DATE_SESSION_KEY
        ] = today

        request.session[
            CHAT_COUNT_SESSION_KEY
        ] = 0

    count = request.session.get(
        CHAT_COUNT_SESSION_KEY,
        0,
    )

    if count >= CHAT_LIMIT:

        return JsonResponse(
            {
                "error": (
                    "JivaAi has reached today's "
                    "50-message limit. "
                    "Please come back tomorrow."
                )
            },
            status=429,
        )

    # ========================================================
    # RAG
    # ========================================================

    try:

        result = handle_query(
            question
        )

        answer = result["answer"]

    except ValueError as exc:

        return JsonResponse(
            {
                "error": str(exc)
            },
            status=503,
        )

    except Exception as exc:

        print(
            "JivaAi Error:",
            repr(exc),
        )

        return JsonResponse(
            {
                "error": (
                    "JivaAi could not answer "
                    "right now. Please try again."
                )
            },
            status=502,
        )

    # ========================================================
    # UPDATE LIMIT
    # ========================================================

    request.session[
        CHAT_COUNT_SESSION_KEY
    ] = count + 1

    request.session.modified = True

    return JsonResponse(
        {
            "answer": answer,
            "remaining": (
                CHAT_LIMIT - count - 1
            ),
        }
    )




def home(request):

    profile = Profile.objects.filter(
        is_active=True
    ).first()

    skills = Skill.objects.filter(
        is_active=True
    ).order_by("display_order", "name")

    technologies = Technology.objects.filter(
        is_active=True
    ).order_by("display_order", "name")

    education = Education.objects.filter(
        is_active=True
    ).order_by("display_order")

    experiences = Experience.objects.filter(
        is_active=True
    ).order_by("display_order")

    services = Service.objects.filter(
        is_active=True
    ).order_by("display_order")

    projects = Project.objects.filter(
        is_active=True
    ).order_by("display_order", "-created_at")

    testimonials = Testimonial.objects.filter(
        is_active=True
    ).order_by("display_order")

    statistics = SiteStatistic.objects.filter(
        is_active=True
    ).order_by("display_order")

    context = {
        "profile": profile,
        "skills": skills,
        "technologies": technologies,
        "education": education,
        "experiences": experiences,
        "services": services,
        "projects": projects,
        "testimonials": testimonials,
        "statistics": statistics,
        "has_profile": bool(profile),
        "has_skills": skills.exists(),
        "has_technologies": technologies.exists(),
        "has_education": education.exists(),
        "has_experiences": experiences.exists(),
        "has_services": services.exists(),
        "has_projects": projects.exists(),
        "has_testimonials": testimonials.exists(),
        "has_statistics": statistics.exists(),
    }

    return render(
        request,
        "index.html",
        context
    )


# ============================================================
# CONTACT FORM
# ============================================================

def contact_submit(request):

    if request.method == "POST":

        name = request.POST.get("name", "").strip()
        email = request.POST.get("email", "").strip()
        subject = request.POST.get("subject", "").strip()
        message = request.POST.get("message", "").strip()

        if name and email and subject and message:

            ContactMessage.objects.create(
                name=name,
                email=email,
                subject=subject,
                message=message,
            )

            messages.success(
                request,
                "Your message has been sent successfully!"
            )

        else:

            messages.error(
                request,
                "Please fill all required fields."
            )

    return redirect("core:home")