from django.db import models


# ============================================================
# PROFILE
# ============================================================

class Profile(models.Model):
    name = models.CharField(max_length=150)
    full_name = models.CharField(max_length=200)

    role = models.CharField(
        max_length=200,
        default="Front-End & Python Developer"
    )

    hero_title_line1 = models.CharField(
        max_length=200,
        default="Crafting pixel-perfect"
    )

    hero_title_line2 = models.CharField(
        max_length=200,
        default="interfaces & clean"
    )

    hero_title_line3 = models.CharField(
        max_length=200,
        default="Python backends."
    )

    short_bio = models.TextField()

    about_title = models.CharField(
        max_length=200,
        default="Front-End Developer & Python enthusiast"
    )

    about_description_1 = models.TextField()
    about_description_2 = models.TextField()

    email = models.EmailField()
    phone_primary = models.CharField(max_length=30)
    phone_secondary = models.CharField(
        max_length=30,
        blank=True
    )

    age = models.PositiveIntegerField(
        null=True,
        blank=True
    )

    experience = models.CharField(
        max_length=100,
        default="Fresher"
    )

    address = models.CharField(max_length=300)

    availability_text = models.CharField(
        max_length=200,
        default="Available for freelance & full-time roles"
    )

    profile_image = models.ImageField(
        upload_to="profile/",
        blank=True,
        null=True
    )

    resume = models.FileField(
        upload_to="resume/",
        blank=True,
        null=True
    )

    github = models.URLField(blank=True)
    linkedin = models.URLField(blank=True)
    twitter = models.URLField(blank=True)
    instagram = models.URLField(blank=True)

    is_active = models.BooleanField(default=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Profile"
        verbose_name_plural = "Profile"

    def __str__(self):
        return self.name


# ============================================================
# SKILLS
# ============================================================

class Skill(models.Model):

    CATEGORY_CHOICES = [
        ("frontend", "Frontend"),
        ("backend", "Backend"),
        ("programming", "Programming"),
        ("database", "Database"),
        ("tools", "Tools"),
        ("other", "Other"),
    ]

    name = models.CharField(max_length=100)

    category = models.CharField(
        max_length=30,
        choices=CATEGORY_CHOICES,
        default="other"
    )

    icon = models.CharField(
        max_length=100,
        help_text="Font Awesome class, e.g. fa-brands fa-python"
    )

    icon_color = models.CharField(
        max_length=20,
        default="#EC4899"
    )

    percentage = models.PositiveIntegerField(
        default=80
    )

    description = models.TextField(
        blank=True
    )

    is_primary = models.BooleanField(
        default=True
    )

    display_order = models.PositiveIntegerField(
        default=0
    )

    is_active = models.BooleanField(
        default=True
    )

    class Meta:
        ordering = ["display_order", "name"]

    def __str__(self):
        return self.name


# ============================================================
# TECHNOLOGIES / ALSO FAMILIAR WITH
# ============================================================

class Technology(models.Model):

    name = models.CharField(max_length=100)

    icon = models.CharField(
        max_length=100,
        blank=True,
        help_text="Font Awesome class"
    )

    display_order = models.PositiveIntegerField(
        default=0
    )

    is_active = models.BooleanField(
        default=True
    )

    class Meta:
        ordering = ["display_order", "name"]

    def __str__(self):
        return self.name


# ============================================================
# EDUCATION
# ============================================================

class Education(models.Model):

    degree = models.CharField(max_length=200)

    field_of_study = models.CharField(
        max_length=200,
        blank=True
    )

    institution = models.CharField(
        max_length=300
    )

    start_year = models.CharField(
        max_length=20
    )

    end_year = models.CharField(
        max_length=20
    )

    description = models.TextField(
        blank=True
    )

    grade = models.CharField(
        max_length=50,
        blank=True
    )

    display_order = models.PositiveIntegerField(
        default=0
    )

    is_active = models.BooleanField(
        default=True
    )

    class Meta:
        ordering = ["display_order"]

    def __str__(self):
        return f"{self.degree} - {self.institution}"


# ============================================================
# EXPERIENCE
# ============================================================

class Experience(models.Model):

    title = models.CharField(
        max_length=200
    )

    company = models.CharField(
        max_length=200,
        blank=True
    )

    start_date = models.CharField(
        max_length=50
    )

    end_date = models.CharField(
        max_length=50
    )

    description = models.TextField()

    technologies = models.CharField(
        max_length=500,
        blank=True,
        help_text="Example: Python, Django, SQL, Bootstrap"
    )

    display_order = models.PositiveIntegerField(
        default=0
    )

    is_active = models.BooleanField(
        default=True
    )

    class Meta:
        ordering = ["display_order"]

    def __str__(self):
        return self.title


# ============================================================
# SERVICES
# ============================================================

class Service(models.Model):

    title = models.CharField(
        max_length=200
    )

    icon = models.CharField(
        max_length=100,
        help_text="Font Awesome class"
    )

    description = models.TextField()

    display_order = models.PositiveIntegerField(
        default=0
    )

    is_active = models.BooleanField(
        default=True
    )

    class Meta:
        ordering = ["display_order"]

    def __str__(self):
        return self.title


# ============================================================
# PROJECTS
# ============================================================

class Project(models.Model):

    CATEGORY_CHOICES = [
        ("web", "Web Development"),
        ("python", "Python"),
        ("wp", "WordPress"),
        ("ai", "AI / ML"),
        ("django", "Django"),
        ("other", "Other"),
    ]

    title = models.CharField(
        max_length=200
    )

    category = models.CharField(
        max_length=30,
        choices=CATEGORY_CHOICES
    )

    category_label = models.CharField(
        max_length=100,
        blank=True
    )

    description = models.TextField()

    icon = models.CharField(
        max_length=100,
        help_text="Font Awesome class"
    )

    gradient_start = models.CharField(
        max_length=20,
        default="#3B2E7A"
    )

    gradient_end = models.CharField(
        max_length=20,
        default="#7C6FF0"
    )

    image = models.ImageField(
        upload_to="projects/",
        blank=True,
        null=True
    )

    live_url = models.URLField(
        blank=True
    )

    github_url = models.URLField(
        blank=True
    )

    technologies = models.CharField(
        max_length=500,
        blank=True,
        help_text="Example: HTML, CSS, Bootstrap, JavaScript"
    )

    featured = models.BooleanField(
        default=False
    )

    display_order = models.PositiveIntegerField(
        default=0
    )

    is_active = models.BooleanField(
        default=True
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    class Meta:
        ordering = ["display_order", "-created_at"]

    def __str__(self):
        return self.title


# ============================================================
# TESTIMONIALS
# ============================================================

class Testimonial(models.Model):

    name = models.CharField(
        max_length=150
    )

    designation = models.CharField(
        max_length=200,
        blank=True
    )

    company = models.CharField(
        max_length=200,
        blank=True
    )

    message = models.TextField()

    avatar = models.CharField(
        max_length=10,
        blank=True,
        help_text="Example: RS"
    )

    image = models.ImageField(
        upload_to="testimonials/",
        blank=True,
        null=True
    )

    display_order = models.PositiveIntegerField(
        default=0
    )

    is_active = models.BooleanField(
        default=True
    )

    class Meta:
        ordering = ["display_order"]

    def __str__(self):
        return self.name


# ============================================================
# CONTACT MESSAGES
# ============================================================

class ContactMessage(models.Model):

    name = models.CharField(
        max_length=150
    )

    email = models.EmailField()

    subject = models.CharField(
        max_length=250
    )

    message = models.TextField()

    is_read = models.BooleanField(
        default=False
    )

    created_at = models.DateTimeField(
        auto_now_add=True
    )

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.name} - {self.subject}"


# ============================================================
# SITE STATISTICS
# ============================================================

class SiteStatistic(models.Model):

    STAT_TYPE_CHOICES = [
        ("projects", "Projects Built"),
        ("chai", "Cups of Chai"),
        ("technologies", "Technologies"),
        ("clients", "Happy Clients"),
    ]

    title = models.CharField(
        max_length=100
    )

    stat_type = models.CharField(
        max_length=30,
        choices=STAT_TYPE_CHOICES
    )

    value = models.PositiveIntegerField()

    icon = models.CharField(
        max_length=100
    )

    display_order = models.PositiveIntegerField(
        default=0
    )

    is_active = models.BooleanField(
        default=True
    )

    class Meta:
        ordering = ["display_order"]

    def __str__(self):
        return f"{self.title}: {self.value}"