from django.urls import path

from .views import chat_api, home, contact_submit

app_name = "core"

urlpatterns = [
    path("", home, name="home"),
    path("contact/", contact_submit, name="contact_submit"),
    path("api/chat/", chat_api, name="chat_api"),
]
