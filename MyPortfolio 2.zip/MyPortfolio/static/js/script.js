// Minimal page script to enable interactive bits referenced by index.html
(function(){
  'use strict';

  // Set current year
  const yearEl = document.getElementById('year');
  if(yearEl) yearEl.textContent = new Date().getFullYear();

  // Initialize AOS if available
  if(window.AOS && typeof AOS.init === 'function'){
    AOS.init({once:true, duration:600});
  }

  // Scroll progress bar
  const prog = document.getElementById('scrollProgress');
  function updateProgress(){
    if(!prog) return;
    const docH = document.documentElement.scrollHeight - window.innerHeight;
    const pct = docH > 0 ? (window.scrollY / docH) * 100 : 0;
    prog.style.width = pct + '%';
  }
  updateProgress();
  window.addEventListener('scroll', updateProgress, {passive:true});

  // Simple stat counter animation
  const counters = Array.from(document.querySelectorAll('.stat-num[data-count]'));
  function animateCounters(){
    counters.forEach(el => {
      const target = parseInt(el.getAttribute('data-count') || '0',10);
      if(isNaN(target) || target <= 0) return;
      const start = 0; const duration = 1200; const stepTime = 20;
      let elapsed = 0;
      const tick = () => {
        elapsed += stepTime;
        const pct = Math.min(1, elapsed / duration);
        el.textContent = Math.floor(pct * (target - start) + start);
        if(pct < 1) setTimeout(tick, stepTime);
        else el.textContent = String(target);
      };
      tick();
    });
  }
  // Run counters when visible
  if('IntersectionObserver' in window && counters.length){
    const obs = new IntersectionObserver((entries, o)=>{
      entries.forEach(e=>{ if(e.isIntersecting){ animateCounters(); o.disconnect(); }});
    },{threshold:0.4});
    obs.observe(counters[0]);
  } else {
    animateCounters();
  }

  // Project filters
  const filterBar = document.querySelector('.filter-bar');
  if(filterBar){
    filterBar.addEventListener('click', e => {
      const btn = e.target.closest('.filter-btn');
      if(!btn) return;
      Array.from(filterBar.querySelectorAll('.filter-btn')).forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      const filter = btn.getAttribute('data-filter');
      const items = document.querySelectorAll('#projectGrid .project-item');
      items.forEach(it => {
        const cats = (it.getAttribute('data-cat')||'').split(/\s+/);
        if(filter === 'all' || cats.includes(filter)) it.style.display = '';
        else it.style.display = 'none';
      });
    });
  }

  // Own the window state independently from the page's larger inline script.
  window.setTimeout(() => {
    const toggle = document.getElementById('chatToggle');
    const widget = document.querySelector('.chat-widget');
    const windowEl = document.getElementById('chatWindow');
    const close = document.getElementById('chatClose');
    const body = document.getElementById('chatBody');
    if(!toggle || !widget || !windowEl) return;

    const resetHistory = () => {
      if(!body) return;
      body.replaceChildren();
      const message = document.createElement('div');
      message.className = 'msg msg-bot';
      const avatar = document.createElement('span');
      avatar.className = 'chat-avatar sm';
      avatar.innerHTML = '<i class="fa-solid fa-robot"></i>';
      const bubble = document.createElement('div');
      bubble.className = 'bubble';
      const hour = new Date().getHours();
      const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
      bubble.textContent = `${greeting}! I am JivaAi, Jivan's read-only portfolio assistant.`;
      message.append(avatar, bubble);
      body.appendChild(message);
    };

    toggle.addEventListener('click', () => {
      const open = !widget.classList.contains('open');
      widget.classList.toggle('open', open);
      toggle.classList.toggle('active', open);
      if(open) resetHistory();
    });
    close?.addEventListener('click', () => {
      widget.classList.remove('open');
      toggle.classList.remove('active');
      resetHistory();
    });
  }, 0);

})();
